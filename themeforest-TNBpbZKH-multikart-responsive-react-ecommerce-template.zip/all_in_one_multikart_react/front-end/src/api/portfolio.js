
// Grid Columns Photos

export const photos = [
    {
      src: require('../assets/images/portfolio/grid/1.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/grid/2.jpg'),
      type: 'shoes'
    },
    {
      src: require('../assets/images/portfolio/grid/3.jpg'),
      type: 'bags'
    },
    {
      src: require('../assets/images/portfolio/grid/4.jpg'),
      type: 'bags'
    },
    {
      src: require('../assets/images/portfolio/grid/5.jpg'),
      type: 'bags'
    },
    {
      src: require('../assets/images/portfolio/grid/6.jpg'),
      type: 'watch'
    },
    {
      src: require('../assets/images/portfolio/grid/7.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/grid/8.jpg'),
      type: 'bags'
    },
    {
      src: require('../assets/images/portfolio/grid/9.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/grid/10.jpg'),
      type: 'shoes'
    },
    {
      src: require('../assets/images/portfolio/grid/11.jpg'),
      type: 'bags'
    },
    {
      src: require('../assets/images/portfolio/grid/12.jpg'),
      type: 'bags'
    },
  ]

  // Masonary Photos

  export const MasonaryPhotos = [
    {
      src: require('../assets/images/portfolio/1.jpg'),
      type: 'shoes'
    },
    {
      src: require('../assets/images/portfolio/2.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/3.jpg'),
      type: 'shoes'
    },
    {
      src: require('../assets/images/portfolio/4.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/5.jpg'),
      type: 'watch'
    },
    {
      src: require('../assets/images/portfolio/6.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/7.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/8.jpg'),
      type: 'bags'
    },
    {
      src: require('../assets/images/portfolio/9.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/10.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/11.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/12.jpg'),
      type: 'bags'
    },
    {
      src: require('../assets/images/portfolio/13.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/14.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/15.jpg'),
      type: 'watch'
    },
    {
      src: require('../assets/images/portfolio/16.jpg'),
      type: 'bags'
    },
    {
      src: require('../assets/images/portfolio/17.jpg'),
      type: 'watch'
    },
    {
      src: require('../assets/images/portfolio/18.jpg'),
      type: 'watch'
    },
    {
      src: require('../assets/images/portfolio/19.jpg'),
      type: 'bags'
    },
    {
      src: require('../assets/images/portfolio/20.jpg'),
      type: 'watch'
    },
    {
      src: require('../assets/images/portfolio/21.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/22.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/23.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/24.jpg'),
      type: 'bags'
    },
    {
      src: require('../assets/images/portfolio/25.jpg'),
      type: 'fashion'
    },
    {
      src: require('../assets/images/portfolio/26.jpg'),
      type: 'fashion'
    },
  ]